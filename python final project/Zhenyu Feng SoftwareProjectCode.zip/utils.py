import xml.etree.ElementTree as ET
import string

from stemming.porter2 import stem
import math
from collections import Counter
from collections import OrderedDict





# parse and preprocess the xml file and file

def parse_and_process_xml(file_dir):
    # file_dir: the path of the xml file

    tree = ET.parse(file_dir)
    root = tree.getroot()
    all_doc_info = {}

    for doc in root.findall("DOC"):
        doc_id = doc.get("id")
        doc_type = doc.get("type")

        # get the headline
        headline = doc.find("HEADLINE").text if doc.find("HEADLINE") is not None else ""

        # get the text content
        text_element = doc.find("TEXT")
        text_content_list = []

        # concatatenate headline and text
        if headline:
            text_content_list.append(headline.lower().strip().replace("\n", " "))

        if text_element is not None:
            # if there are <P> tags in TEXT
            if text_element.findall("P"):
                for p in text_element.findall("P"):
                    if p.text:
                        text_content_list.append(p.text.lower().strip().replace("\n", " "))
            else: # if there are no <P> tags in TEXT
                if text_element.text: # if there is text in TEXT
                    text_content_list.append(text_element.text.lower().strip().replace("\n", " "))

        # process the text content
        text_content = " ".join(text_content_list)
        text_content = text_content.replace("-", " ")
        text_content = text_content.translate(str.maketrans("", "", string.punctuation))

        # stem the words
        word_list = [stem(word) for word in text_content.split()] if text_content.strip() else []

        # store the doc info
        all_doc_info[doc_id] = {
            "type": doc_type,
            "headline": headline,
            "word_list": word_list
        }

    return all_doc_info # format: {doc_id: {"type": type, "headline": headline, "word_list": word_list}, ...}


# to get the unique word list in all docs
def get_unique_word_list(all_doc_info):
    # all_doc_info: the dictionary of all docs

    lists_of_word_list = [all_doc_info[doc_id]["word_list"] for doc_id in all_doc_info]
    merged_list = [word for word_list in lists_of_word_list for word in word_list]
    unique_word_lists = list(set(merged_list))
    # sort the list and determine the index in the tf and idf
    unique_word_lists = sorted(unique_word_lists)
    return unique_word_lists


# to get the idf of each word
def count_idf_sum(all_doc_info, unique_word_list):
    word_frequency = {}
    for word in unique_word_list:
        word_frequency[word] = 0
        for doc_id in all_doc_info:
            if word in all_doc_info[doc_id]["word_list"]:
                word_frequency[word] += 1
    return word_frequency



def get_idf(all_doc_info, unique_word_list, doc_name):

    # to get the document frequency of each word
    doc_freq = Counter()
    for doc_id, doc_info in all_doc_info.items():
        unique_words_in_doc = set(doc_info["word_list"])
        doc_freq.update(unique_words_in_doc)

    # to calculate the idf of each word
    doc_num = len(all_doc_info)
    idf_dict = OrderedDict()

    for word in unique_word_list:
        idf_value = math.log(doc_num / (doc_freq.get(word, 1)))
        idf_dict[word] = idf_value

    # to write the idf to a file
    write_file_name = f"{doc_name}.idf"
    with open(write_file_name, "w", encoding="utf-8") as f:
        for word, idf in idf_dict.items():
            f.write(f"{word}\t{idf:.6f}\n")

    print(f"IDF file has been written to {write_file_name}")

    return idf_dict # format: {word: idf, ...}


def get_tf(all_doc_info, unique_word_list, doc_name):

    tf_dict = {}
    # to get max count of each word in each doc
    for doc_id, doc_info in all_doc_info.items():
        word_count = Counter(doc_info["word_list"])
        max_count = max(word_count.values(), default=1)

        # only store the non-zero tf, to reduce the I/O cost and memory cost
        tf_dict[doc_id] = {word: count / max_count for word, count in word_count.items()}

    # to write the tf to a file
    write_file_name = f"{doc_name}.tf"
    with open(write_file_name, "w", encoding="utf-8") as f:
        f.writelines(
            f"{doc_id}\t{word}\t{tf:.6f}\n"
            for doc_id, word_dict in tf_dict.items()
            for word, tf in word_dict.items()
        )

    print(f"TF file has been written to {write_file_name}")

    return tf_dict # format: {doc_id: {word: tf}, ...}


def tf_idf(tf_dict, idf_dict):
    # to calculate the tf-idf of each word in each doc; only store the non-zero tf-idf to save memory
    tf_idf_dict = {}

    # to calculate the tf-idf of each word in each doc, only store the non-zero tf-idf
    for doc_id, tf_values in tf_dict.items():
        tf_idf_dict[doc_id] = {word: tf * idf_dict.get(word, 1) for word, tf in tf_values.items()}

    return tf_idf_dict


def get_query_list(query_sentence):
    # query text preprocessing
    query_list = query_sentence.replace("-", " ")
    # remove punctuation
    query_list = query_list.translate(str.maketrans("", "", string.punctuation))
    # convert to lower case and split
    query_list = [stem(word) for word in query_list.split()] if query_list.strip() else []
    return query_list

def get_query_vector(query_sentence, idf_dict):
    # to get the query list
    query_list = [stem(word) for word in query_sentence]
    query_word_count = Counter(query_list)
    # to get the max term frequency
    max_tf = max(query_word_count.values(), default=1)

    # to calculate the tf-idf of each word in the query, only store the non-zero tf-idf to save memory
    query_tf_idf_vector = {
        word: (query_word_count[word] / max_tf) * idf_dict.get(word, 0)
        for word in query_word_count if word in idf_dict
    }

    return query_tf_idf_vector

# to calculate the cosine similarity
def cos_similarity(query_tf_idf_vector, tf_idf_vector_dict):
    similarity_dict = {}

    for doc_id, doc_vector in tf_idf_vector_dict.items():
        # if not isinstance(doc_vector, dict):
        #     raise ValueError(f" ERROR: `doc_vector` for {doc_id} is not a dict!")

        # to get the common words in the query and the doc, because they are both sparse
        common_words = set(query_tf_idf_vector.keys()) & set(doc_vector.keys())
        dot_product = sum(query_tf_idf_vector[word] * doc_vector[word] for word in common_words)

        #  calculate the norm of the query and the doc
        norm_query = math.sqrt(sum(value**2 for value in query_tf_idf_vector.values()))
        norm_doc = math.sqrt(sum(value**2 for value in doc_vector.values()))

        #  to avoid the zero division error
        if norm_query == 0 or norm_doc == 0:
            similarity = 0
        else:
            similarity = dot_product / (norm_query * norm_doc)

        similarity_dict[doc_id] = similarity

    return similarity_dict


# to read the idf from a file
def read_from_idf(file_dir):
    idf_dict = {}
    with open(file_dir, "r", encoding="utf-8") as f:
        for line in f:
            word, idf = line.strip().split("\t")
            idf_dict[word] = float(idf)
    return idf_dict

def read_from_tf(file_dir):
    tf_dict = {}
    with open(file_dir, "r", encoding="utf-8") as f:
        for line in f:
            doc_id, word, tf = line.strip().split("\t")
            if doc_id not in tf_dict:
                tf_dict[doc_id] = {}
            tf_dict[doc_id][word] = float(tf)
    return tf_dict
