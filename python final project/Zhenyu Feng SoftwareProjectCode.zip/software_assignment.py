"""
Introduction to Python Programming
Software Assignment
(33 points)
"""

# import libraries
import xml.etree.ElementTree as ET
import string
from stemming.porter2 import stem

# import all functions in test.py
from utils import *


class SearchEngine:

    def __init__(self, collection_name, create):
        """
        Initialize the search engine, i.e. create or read in index. If
        create=True, the search index should be created and written to
        files. If create=False, the search index should be read from
        the files. The collection_name points to the filename of the
        document collection (without the .xml at the end). Hence, you
        can read the documents from <collection_name>.xml, and should
        write / read the idf index to / from <collection_name>.idf, and
        the tf index to / from <collection_name>.tf respectively. All
        of these files must reside in the same folder as THIS file. If
        your program does not adhere to this "interface
        specification", we will subtract some points as it will be
        impossible for us to test your program automatically!
        """
        self.doc_name = collection_name
        self.collection_name = f"{collection_name}.xml"

        # create and write to files
        if create == True:
            # parse and process the xml file
            print("Start parsing and processing the xml file.")
            self.all_docs_info = parse_and_process_xml(self.collection_name)
            print("Finish parsing and processing the xml file.")

            # get unique word list
            self.unique_word_list = get_unique_word_list(self.all_docs_info)
            print("Finish getting unique word list.")

            # get idf and tf
            self.idf_dict = get_idf(self.all_docs_info, self.unique_word_list, doc_name = self.doc_name)
            print("Finish getting idf.")

            self.tf_dict = get_tf(self.all_docs_info, self.unique_word_list, doc_name = self.doc_name)
            print("Finish getting tf.")

            # get tf_idf
            self.tf_idf_vector_dict = tf_idf(self.tf_dict, self.idf_dict)
            print("Finish getting tf_idf.")

        # read from files
        if create == False:
            # read tf & idf from files
            print("Start Reading tf...")
            self.tf_dict = read_from_tf(f"{collection_name}.tf")
            print("Finish reading tf.")

            print("Start Reading idf...")
            self.idf_dict = read_from_idf(f"{collection_name}.idf")
            print("Finish reading idf.")

            # get unique word list
            self.unique_word_list = list(self.idf_dict.keys())
            # get tf_idf
            self.tf_idf_vector_dict = tf_idf(self.tf_dict, self.idf_dict)

    def execute_query(self, query_terms):
        """
        Input to this function: List of query terms

        Returns the 10 highest ranked documents together with their
        relevance scores, sorted by score. For instance,

        [('NYT_ENG_19950101.0001', 0.07237004260325626),
         ('NYT_ENG_19950101.0022', 0.013039249597972629), ...]

        May be less than 10 documents if there aren't as many documents
        that contain the terms.
        """
        # get query vector
        self.query_terms = query_terms
        # tf_idf of query terms
        self.query_stem_list = get_query_vector(self.query_terms, self.idf_dict)
        # calculate similarity
        self.similarity = cos_similarity(self.query_stem_list, self.tf_idf_vector_dict)
        # get non-zero similarity
        non_zero_similarity = {doc_id: score for doc_id, score in self.similarity.items() if score > 0}
        # sort similarity
        self.sorted_similarity = sorted(non_zero_similarity.items(), key=lambda x: x[1], reverse=True)[:10]

        return self.sorted_similarity if self.sorted_similarity else []

    def execute_query_console(self):
        """
        When calling this, the interactive console should be started,
        ask for queries and display the search results, until the user
        simply hits enter.
        """
        while True:
            query = input("\nPlease enter query terms separated by whitespace: ").strip().lower().replace("\n", " ")

            if not query: # if user simply hits enter, exit
                print("Exit.")
                break

            query_terms = get_query_list(query)

            # search
            results = self.execute_query(query_terms)

            # if no results
            if not results:
                print("Sorry, I didn’t find any documents for this term.")
            else:
                print("I found the following documents:")
                for doc_id, score in results:
                    print(f"{doc_id}\t{score}")

if __name__ == '__main__':
    """
    write your code here:
    * load index / start search engine
    * start the loop asking for query terms
    * program should quit if users enters no term and simply hits enter
    """
    # Example for how we might test your program:
    # Should also work with nyt199501 !
    search_engine = SearchEngine("nyt199501", create= False)
    print(search_engine.execute_query(['hurricane', 'philadelphia']))
    search_engine.execute_query_console()
