# README  

## Author  
Zhenyu Feng

## Directory Structure
.  
├── assignment3.ipynb  
├── 5trees(5 pngs)   
├── treenumber.txt   
└── README.md 

## Versions  

- Python: 3.7.6
- nltk: 3.4.5

## Runtime  
Overall runtime on my pc: around 2min 30s 

## External Material  
 

## Additional Features
