# README  

## Author  
Zhenyu Feng

## Directory Structure
.  
├── assignment 4 of Coli.ipynb  
├── HMM_Learning_Curve.png  
├── accuracy on val dataset.png  
├── training loss of train dataset.png      
└── readme.md 

## Versions  

- Python: 3.9.18
- datasets: 2.19.1
- transformers: 4.45.2
- torch: 2.0.0+cu118


## Runtime  
The runtime depends on GPU.     

Overall runtime on kaggle GPU P100: around 10-15min.
On my ancient pc with 1050ti, it can take more than 1 hour.

## External Material  
 

## Additional Features
