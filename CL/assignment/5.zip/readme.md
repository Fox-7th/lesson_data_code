# README  

## Author  
Zhenyu Feng

## Directory Structure
.  
├── assignment 5.ipynb  
├── accuracy head tagging.png  
├── train loss.png  
├── valid loss.png     
└── readme.md 

## Versions  

- Python: 3.10.12
- datasets: 3.2.0
- transformers: 4.44.2
- torch: 2.4.1+cu121
- wandb: 0.19.1


## Runtime  
The runtime depends on GPU.     

Overall runtime on kaggle GPU P100: around 20 min.

## External Material  
 

## Additional Features
