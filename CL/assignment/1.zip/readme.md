# README  

## Author  

Zhenyu Feng

## Directory Structure
.  
├── Zipf's Law.ipynb  
├── README.md  
├── King James Bible.txt.png  
├── The Jungle Book.txt.png  
├── SETIMES.bg-tr.bg.png  
└── SETIMES.bg-tr.tr.png  


## Versions  

- Python: 3.7.6
- NLTK version: 3.4.5
- Matplotlib version: 3.1.3

## Runtime  

overall runtime on my pc: 88.3074s 

## External Material  

 

## Additional Features  

I draw a line between the most and least frequnt words to see how close the log line is to the straight line. Also, I list out top 10 frequnt words/punctuations to compare 2 English Texts.
Also, I count words in texts so we can see the how frequent most frequnt 10 words are in the texts.