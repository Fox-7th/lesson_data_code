# README  

## Author  
Zhenyu Feng

## Directory Structure
.  
├── POS tagging with HMMs.ipynb  
├── instructions.txt   
├── Learning_Curve.png  
└── README.md 

## Versions  

- Python: 3.7.6
- conllu version: 4.5.3
- Matplotlib version: 3.1.3

## Runtime  

Overall runtime on my pc: 70s 

## External Material  

 

## Additional Features
 I plot a learning curve for my tagger to try to get extra credits.